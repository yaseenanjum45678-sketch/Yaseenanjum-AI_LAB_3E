import heapq

graph = {
    "S": [("A", 1), ("B", 4)],
    "A": [("C", 2)],
    "B": [("G", 5)],
    "C": [("G", 3)],
    "G": [],
}

h_given = {"S": 5, "A": 4, "B": 4, "C": 2, "G": 0}
h_zero = {n: 0 for n in graph}
h_over = dict(h_given)
h_over["C"] = 10


def search(graph, h, start, goal):
    pq = [(h[start], 0, start, [start])]
    best = {start: 0}
    expanded = []
    processed = []
    steps = []
    while pq:
        f, g, node, path = heapq.heappop(pq)
        if g != best[node]:
            continue
        processed.append(node)
        if node == goal:
            return g, path, expanded, processed, steps
        expanded.append(node)
        for nxt, w in graph.get(node, []):
            ng = g + w
            if ng < best.get(nxt, float("inf")):
                best[nxt] = ng
                heapq.heappush(pq, (ng + h[nxt], ng, nxt, path + [nxt]))
        frontier = [(n, gg, h[n], ff) for ff, gg, n, p in sorted(pq) if gg == best[n]]
        steps.append(((node, g, h[node], f), frontier))
    return None


def path_cost(graph, path):
    total = 0
    for a, b in zip(path, path[1:]):
        total += dict(graph[a])[b]
    return total


def show(title, graph, h, start, goal):
    print(title)
    result = search(graph, h, start, goal)
    if result is None:
        print("No path found")
        print()
        return
    g, path, expanded, processed, steps = result
    print("Path:", " -> ".join(path))
    print("Returned cost:", g)
    print("Summed cost:", path_cost(graph, path))
    print("Processed:", processed)
    print("Expanded:", expanded)
    print("Expansion count:", len(expanded))
    for i, (sel, frontier) in enumerate(steps, 1):
        print("Step", i, "selected (node,g,h,f):", sel)
        print("   frontier after:", frontier)
    print()


def audit(graph, h):
    print("Consistency check h(u) <= cost + h(v)")
    for u in graph:
        for v, w in graph[u]:
            ok = h[u] <= w + h[v]
            print(u, "->", v, ":", h[u], "<=", w, "+", h[v], "=", w + h[v], ok)
    print()


true_cost = {"S": 6, "A": 5, "B": 5, "C": 3, "G": 0}
print("Admissibility check h(n) <= true cost")
for n in graph:
    print(n, h_given[n], "<=", true_cost[n], h_given[n] <= true_cost[n])
print()

audit(graph, h_given)
show("A* with given heuristic", graph, h_given, "S", "G")
show("UCS with zero heuristic", graph, h_zero, "S", "G")
show("A* with h(C)=10", graph, h_over, "S", "G")

graph_edge = dict(graph)
graph_edge["D"] = []
h_edge = dict(h_given)
h_edge["D"] = 0
show("Edge case: unreachable goal D", graph_edge, h_edge, "S", "D")
