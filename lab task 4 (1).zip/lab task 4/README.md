Lab 4: Informed Search, Heuristics and A*
Rasikh Ali - 42365 | CAI601400 Artificial Intelligence

Files
lab4_astar_audit.py : A* and UCS code with heuristic audit, overestimate test and edge case
lab4_output.txt : captured output of the code
Lab4_Report.docx : lab report

Setup
Python 3 is required. No extra libraries are needed.

Run
python lab4_astar_audit.py

Save output
python lab4_astar_audit.py > lab4_output.txt
