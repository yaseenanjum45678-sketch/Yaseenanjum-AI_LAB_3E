import heapq
from collections import deque

graph = {"A": ["B", "C"], "B": ["D", "E"], "C": ["F"], "D": [], "E": ["G"], "F": [], "G": []}

weighted = {
    "A": [("B", 1), ("C", 5)],
    "B": [("D", 2), ("E", 1)],
    "C": [("F", 3), ("G", 7)],
    "D": [],
    "E": [("G", 1)],
    "F": [],
    "G": [],
}


def bfs(g, start, goal):
    q = deque([(start, [start])])
    seen = {start}
    order = []
    while q:
        node, path = q.popleft()
        order.append(node)
        print("  processed", node, "| path", path, "| queue", [x[0] for x in q])
        if node == goal:
            return path, order
        for n in g[node]:
            if n not in seen:
                seen.add(n)
                q.append((n, path + [n]))
    return None, order


def dfs(g, start, goal):
    stack = [(start, [start])]
    seen = set()
    order = []
    while stack:
        node, path = stack.pop()
        if node in seen:
            continue
        order.append(node)
        seen.add(node)
        print("  processed", node, "| path", path, "| stack", [x[0] for x in stack])
        if node == goal:
            return path, order
        for n in reversed(g[node]):
            stack.append((n, path + [n]))
    return None, order


def dls(g, node, goal, limit, path):
    if node == goal:
        return "FOUND", path
    children = [n for n in g[node] if n not in path]
    if limit == 0:
        return ("CUTOFF" if children else "FAILURE"), None
    cutoff = False
    for n in children:
        status, result = dls(g, n, goal, limit - 1, path + [n])
        if status == "FOUND":
            return status, result
        if status == "CUTOFF":
            cutoff = True
    return ("CUTOFF" if cutoff else "FAILURE"), None


def iddfs(g, start, goal, max_depth):
    tried = []
    status, path = "FAILURE", None
    for limit in range(max_depth + 1):
        tried.append(limit)
        status, path = dls(g, start, goal, limit, [start])
        if status == "FOUND":
            return status, path, tried
    return status, path, tried


def ucs(g, start, goal):
    heap = [(0, start, [start])]
    done = set()
    order = []
    while heap:
        cost, node, path = heapq.heappop(heap)
        if node in done:
            continue
        done.add(node)
        order.append((node, cost))
        if node == goal:
            return path, cost, order
        for n, w in g[node]:
            if n not in done:
                heapq.heappush(heap, (cost + w, n, path + [n]))
    return None, None, order


def path_cost(g, path):
    total = 0
    for a, b in zip(path, path[1:]):
        total += dict(g[a])[b]
    return total


print("TASK 1: BFS AND DFS TRACE")
print("BFS")
p, o = bfs(graph, "A", "G")
print("path:", p, "| visit order:", o)
print("DFS")
p, o = dfs(graph, "A", "G")
print("path:", p, "| visit order:", o)
print()

print("TASK 2: DLS AND IDDFS")
for limit in [1, 2, 3, 4]:
    s, p = dls(graph, "A", "G", limit, ["A"])
    print("DLS limit", limit, "|", s, "|", p)
for m in [1, 2, 3, 4]:
    s, p, t = iddfs(graph, "A", "G", m)
    print("IDDFS max", m, "|", s, "|", p, "| limits tried", t)
print()

print("TASK 3: UCS ON WEIGHTED GRAPH")
unweighted = {k: [n for n, w in v] for k, v in weighted.items()}
print("BFS on extended topology")
bp, bo = bfs(unweighted, "A", "G")
print("BFS path:", bp, "| hops:", len(bp) - 1, "| cost:", path_cost(weighted, bp))
up, uc, uo = ucs(weighted, "A", "G")
print("UCS processing order:", uo)
print("UCS path:", up, "| hops:", len(up) - 1, "| cost:", uc, "| checked cost:", path_cost(weighted, up))
print()

print("EDGE CASES")
print("start equals goal:", bfs(graph, "A", "A")[0])
print("unreachable goal:", bfs(graph, "A", "Z")[0])
cyc = {"A": ["B"], "B": ["A", "C"], "C": []}
print("cycle graph DLS:", dls(cyc, "A", "Z", 5, ["A"]))
