class ReflexAgent:
    def act(self, temp, occupied):
        if not occupied:
            return "ECO"
        if temp > 26:
            return "COOL"
        if temp < 20:
            return "WARM"
        return "IDLE"


class StatefulAgent:
    def __init__(self):
        self.previous = None
        self.base = ReflexAgent()

    def act(self, temp, occupied):
        target = self.base.act(temp, occupied)
        send = target != self.previous
        self.previous = target
        return target, send


def run(title, percepts):
    print(title)
    reflex = ReflexAgent()
    agent = StatefulAgent()
    reflex_count = 0
    stateful_count = 0
    print("step | previous | percept | target | command")
    for step, percept in enumerate(percepts, 1):
        previous = agent.previous
        reflex.act(*percept)
        reflex_count += 1
        target, send = agent.act(*percept)
        if send:
            stateful_count += 1
        print(step, previous, percept, target, "SEND" if send else "NO COMMAND", sep=" | ")
    print("reflex commands:", reflex_count)
    print("stateful commands:", stateful_count)
    print()


run("PART 1: MODE TRANSITION TRACE", [
    (29, True), (29, True), (20, True), (26, True),
    (19, True), (29, False), (29, False), (24, True),
])

run("PART 2: NOISY SEQUENCE AROUND 26", [
    (26.1, True), (25.9, True), (26.1, True), (25.9, True),
])
