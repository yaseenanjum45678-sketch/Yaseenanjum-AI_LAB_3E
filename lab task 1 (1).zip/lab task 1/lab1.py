def rule_check(score, complete, gpa, attendance):
    if not complete:
        return "Hold", "documents incomplete"
    if score < 70:
        return "Hold", "score below 70"
    if gpa < 2.5:
        return "Hold", "gpa below 2.5"
    if attendance < 75:
        return "Hold", "attendance below 75"
    return "Review", "all conditions met"


def symbolic(score, complete):
    return "Review" if complete and score >= 70 else "Hold"


def threshold(probability):
    return "Review" if probability >= 0.70 else "Hold"


print("PART 1: RULE TESTS")
tests = [
    ("pass", 82, True, 3.2, 90, "Review"),
    ("low_gpa", 82, True, 2.1, 90, "Hold"),
    ("low_attendance", 82, True, 3.2, 60, "Hold"),
    ("boundary", 70, True, 2.5, 75, "Review"),
]
for name, score, complete, gpa, att, expected in tests:
    actual, reason = rule_check(score, complete, gpa, att)
    print("case:", name)
    print("input:", score, complete, gpa, att)
    print("expected:", expected)
    print("actual:", actual)
    print("reason:", reason)
    print("match:", expected == actual)
    print()

print("PART 2: SYMBOLIC VS THRESHOLD")
cases = [
    ("complete_high", 82, True, 0.81),
    ("complete_low", 68, True, 0.74),
    ("incomplete_high", 91, False, 0.88),
    ("boundary", 70, True, 0.70),
]
print("case | symbolic | threshold | disagreement")
for name, score, complete, probability in cases:
    a = symbolic(score, complete)
    b = threshold(probability)
    print(name, a, b, a != b, sep=" | ")
