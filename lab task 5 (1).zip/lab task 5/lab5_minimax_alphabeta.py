import math
import random


def pad(scores):
    depth = math.ceil(math.log2(len(scores)))
    return scores + [0] * (2 ** depth - len(scores)), depth


def minimax(depth, index, max_turn, scores, target, counter):
    if depth == target:
        counter[0] += 1
        return scores[index]
    values = [
        minimax(depth + 1, index * 2 + i, not max_turn, scores, target, counter)
        for i in range(2)
    ]
    return max(values) if max_turn else min(values)


def alphabeta(depth, index, max_turn, scores, target, alpha, beta, counter, log):
    if depth == target:
        counter[0] += 1
        return scores[index]
    if max_turn:
        value = float("-inf")
        for i in range(2):
            value = max(
                value,
                alphabeta(depth + 1, index * 2 + i, False, scores, target, alpha, beta, counter, log),
            )
            alpha = max(alpha, value)
            if alpha >= beta:
                if i == 0:
                    log.append("pruned at depth " + str(depth) + " node " + str(index) + " (MAX) alpha=" + str(alpha) + " beta=" + str(beta))
                break
        return value
    value = float("inf")
    for i in range(2):
        value = min(
            value,
            alphabeta(depth + 1, index * 2 + i, True, scores, target, alpha, beta, counter, log),
        )
        beta = min(beta, value)
        if alpha >= beta:
            if i == 0:
                log.append("pruned at depth " + str(depth) + " node " + str(index) + " (MIN) alpha=" + str(alpha) + " beta=" + str(beta))
            break
    return value


def level_values(scores, target):
    levels = {target: list(scores)}
    for d in range(target - 1, -1, -1):
        below = levels[d + 1]
        pick = max if d % 2 == 0 else min
        levels[d] = [pick(below[i], below[i + 1]) for i in range(0, len(below), 2)]
    return levels


def root_move(scores, target):
    values = [minimax(1, i, False, scores, target, [0]) for i in range(2)]
    return values, ["left", "right"][values.index(max(values))]


def run(title, scores):
    scores, target = pad(list(scores))
    print(title)
    print("Leaves:", scores)
    levels = level_values(scores, target)
    for d in range(target, -1, -1):
        kind = "leaves" if d == target else ("MAX" if d % 2 == 0 else "MIN")
        print("  depth", d, kind, levels[d])
    mm_count = [0]
    mm = minimax(0, 0, True, scores, target, mm_count)
    ab_count = [0]
    log = []
    ab = alphabeta(0, 0, True, scores, target, float("-inf"), float("inf"), ab_count, log)
    values, move = root_move(scores, target)
    print("Minimax value:", mm, "| leaves evaluated:", mm_count[0])
    print("Alpha-beta value:", ab, "| leaves evaluated:", ab_count[0])
    print("Root child values:", values, "-> best move:", move)
    print("Same value:", mm == ab, "| Leaves saved:", mm_count[0] - ab_count[0])
    for line in log:
        print("  ", line)
    print()
    return mm, ab, mm_count[0], ab_count[0]


base = [3, 5, 2, 9, 0, 7, 0, 0]

run("Supplied tree (Minimax example, padded)", base)
run("Supplied tree (alpha-beta example)", [3, 5, 2, 9, 3, 5, 2, 9])

print("Reordering experiment (same tree, different branch order)")
print()
run("Order 1: original", base)
run("Order 2: root children swapped", base[4:] + base[:4])
run("Order 3: best branches first", [5, 3, 9, 2, 0, 0, 7, 0])
run("Order 4: fully reversed", base[::-1])
run("Order 5: mixed order", [3, 5, 9, 2, 7, 0, 0, 0])

print("Edge case: all leaves equal")
run("All equal", [4] * 8)

print("Random comparison test")
random.seed(1)
passed = 0
never_more = 0
total = 600
for _ in range(total):
    size = random.choice([8, 16, 32])
    leaves = [random.randint(0, 9) for _ in range(size)]
    target = int(math.log2(size))
    c1 = [0]
    c2 = [0]
    a = minimax(0, 0, True, leaves, target, c1)
    b = alphabeta(0, 0, True, leaves, target, float("-inf"), float("inf"), c2, [])
    if a == b:
        passed += 1
    if c2[0] <= c1[0]:
        never_more += 1
print("Trees tested:", total)
print("Same root value:", passed, "of", total)
print("Alpha-beta leaves <= Minimax leaves:", never_more, "of", total)
