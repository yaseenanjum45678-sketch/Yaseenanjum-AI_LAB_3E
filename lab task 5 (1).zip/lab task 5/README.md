Lab 5: Adversarial Search - Minimax and Alpha-Beta Pruning
Rasikh Ali - 42365 | CAI601400 Artificial Intelligence

Files
lab5_minimax_alphabeta.py : Minimax and alpha-beta code with leaf counters, reordering test and random test
lab5_output.txt : captured output of the code
Lab5_Report.docx : lab report

Setup
Python 3 is required. No extra libraries are needed.

Run
python lab5_minimax_alphabeta.py

Save output
python lab5_minimax_alphabeta.py > lab5_output.txt
